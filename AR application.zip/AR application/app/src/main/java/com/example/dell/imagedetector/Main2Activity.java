package com.example.dell.imagedetector;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static android.media.MediaRecorder.VideoSource.CAMERA;

public class Main2Activity extends AppCompatActivity {
    private Button gallerybutton;
    private Button camerabutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        gallerybutton = (Button) findViewById(R.id.gallerybutton);
        gallerybutton.setOnClickListener(new View.OnClickListener() {

                                       @Override
                                       public void onClick(View view) {

                                           Intent intent = new Intent(Main2Activity.this, Main3Activity.class);
                                            startActivity(intent);
                                       }
                                   }
        );
        camerabutton = (Button) findViewById(R.id.camerabutton);
        camerabutton.setOnClickListener(new View.OnClickListener() {

                                       @Override
                                       public void onClick(View view) {

                                           Intent intent = new Intent(Main2Activity.this, Main4Activity.class);
                                           startActivity(intent);
                                       }
                                   }
        );

    }
    }